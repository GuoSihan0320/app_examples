// logs.js
const util = require('../../utils/util')

Page({
  data: {
    logs: [],
    username:null,
    password1:null,
    check:false
  },
  bindsubmit(){
      var _this = this
      var storage = wx.getStorageSync('userinformation')
      var username = storage.username
      var password1 = storage.password1
      if(_this.data.check != true){
          wx.showToast({
            title: '请先勾选小程序的《使用协议》',
            icon:"none",
            duration:2000
          })
         return ''
      }
      if(_this.data.username == username){
            if(_this.data.password1 == password1){
                wx.showToast({
                  title: '登陆成功',
                  duration:2000
                })
                 wx.switchTab({
                   url: '/pages/index/index',
                 })
            }
      }else{
          wx.showToast({
            title: '用户名或密码错误',
            icon:"none",
            duration:2000
          })
      }
  },
  onLoad() {
    this.setData({
      logs: (wx.getStorageSync('logs') || []).map(log => {
        return {
          date: util.formatTime(new Date(log)),
          timeStamp: log
        }
      })
    })
  }
})
