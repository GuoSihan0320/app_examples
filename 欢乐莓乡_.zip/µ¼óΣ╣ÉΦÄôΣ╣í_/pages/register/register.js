// pages/register/register.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        username:null,
        password1:null,
        password2:null,
        check:false,
    },
    resiger:function(){
        var _this = this
        if(_this.data.check == true){  //勾选协议才能执行下面操作
        var usernma =  _this.data.username
        var password1 = _this.data.password1
        var password2 = _this.data.password2
        if(password1 == password2){  //两次密码一样才能进行设置缓存
            wx.setStorage({
                "key":"userinformation",
                "data":{
                    "username":usernma,
                    "password1":password1,
                    "password2":password2
                }
            })
            wx.showToast({
              title: '注册成功',
              icon:"none",
              duration:2000
            })
            setTimeout(()=>{
                wx.navigateTo({
                  url: '/pages/logs/logs',
                })
            },1000)
        }else{
            wx.showToast({
              title: '密码不一样',
              icon:"none",
              duration:2000
            })
        }
        }else{
            wx.showToast({
              title: '请同意小程序的《使用协议》',
              icon:"none",
              duration:2000
            })
        }
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})