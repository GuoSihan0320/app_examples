// index.js
Page({
  data: {
    userInfo: "",
    hasUserInfo: false
  },
  
  onShow() {
    if (typeof this.getTabBar === 'function'  && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 0,
        showBar: false
      })
    }
    // 在页面加载时隐藏 TabBar 导航栏
    // wx.hideTabBar();
  },

  ToFruit(event) {
    // wx.getUserProfile({
    //   desc: '展示用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
    //   success: (res) => {
    //     console.log(res)
    //     this.setData({
    //       userInfo: res.userInfo,
    //       hasUserInfo: true
    //     })
    //   }
    // });
    wx.switchTab({
      url: '/pages/fruit/fruit',
    })
  },
})
