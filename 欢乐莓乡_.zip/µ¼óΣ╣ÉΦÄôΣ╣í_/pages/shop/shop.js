// pages/shop/shop.js
Page({
  data: {
    activeIndex: 0, // 当前选中按钮的索引
    goods_list:[
      {
        imageurl:'../../images/show_1.jpg',
        name:'上装',
        desc:'土家民族服饰'
      },
      {
        imageurl:'../../images/show_2.jpg',
        name:'下装',
        desc:'土家民族服饰'
      }
    ],
    acc_list:[
      {
        imageurl:'../../images/show_3.jpg',
        name:'配饰1',
      },
      {
        imageurl:'../../images/show_4.jpg',
        name:'配饰2',
      }
    ]
  },

  handleClick(event) {
    const index = event.currentTarget.dataset.index; // 获取被点击按钮的索引
    this.setData({
      activeIndex: index // 更新选中状态
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    if (typeof this.getTabBar === 'function'  && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 3
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})