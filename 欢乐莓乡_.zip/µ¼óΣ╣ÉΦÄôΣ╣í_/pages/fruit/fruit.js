// pages/fruit/fruit.js
Page({
  data: {
    // 是否显示四个窗口
    show1: false,
    show2: false,
    show3: false,
    show4: false,
    // 是否显示三种水壶，默认false不显示
    show_water: false,
    show_feiliao: false,
    show_chucao: false,
    animationData: null,
    id: 0
  },
  // 动画
  Act(event) {
    const id = event.currentTarget.dataset.type;
    this.setData({
      id: id
    });
    if (id == 1) {
      this.setData({
        show_water: true
      });
    } else if (id == 2) {
      this.setData({
        show_feiliao: true
      });
    } else if (id == 3) {
      this.setData({
        show_chucao: true
      });
    }
    // 创建动画对象
    const animation = wx.createAnimation({
      duration: 1000, // 动画持续时间
      timingFunction: 'ease', // 动画效果
    });
    animation.translateY(20).step();
    animation.rotate(-30).step();
    animation.rotate(30).step();
    // 设置渐变消失效果
    animation.opacity(0).step();
    // 导出动画数据并保存到 data 中
    this.setData({
      animationData: animation.export()
    });
    // 在需要触发动画的时机，调用动画对象的 step() 方法
    this.startAnimation(animation);
  },

  startAnimation: function (animation) {
    // 将动画数据应用到图片组件上
    this.setData({
      animationData: animation.export()
    });
    // 在动画结束后，将图片透明度恢复为1
    setTimeout(() => {
      const resetAnimation = wx.createAnimation({
        duration: 0,
      });
      resetAnimation.opacity(1).step();
      this.setData({
        animationData: resetAnimation.export()
      });
    }, 5000);
    setTimeout(() => {
      if (this.data.id == 1) {
        this.setData({
          show_water: false
        });
      } else if (this.data.id == 2) {
        this.setData({
          show_feiliao: false
        });
      } else if (this.data.id == 3) {
        this.setData({
          show_chucao: false
        });
      }
    }, 3500);
  },

  ToBack() {
    wx.switchTab({
      url: '/pages/index/index',
    })
  },

  showPopup1() {
    this.setData({ show1: true });
  },
  showPopup2() {
    this.setData({ show2: true });
  },
  showPopup3() {
    this.setData({ show3: true });
  },
  showPopup4() {
    this.setData({ show4: true });
  },

  onClose() {
    this.setData({
      show1: false,
      show2: false,
      show3: false,
      show4: false
    });
  },


  onLoad(options) {

  },

  onShow() {
      // wx.showTabBar();
      if (typeof this.getTabBar === 'function'  && this.getTabBar()) {
        this.getTabBar().setData({
          selected: 1
        })
      }
  },

  onHide() {

  },

  onUnload() {

  },

})