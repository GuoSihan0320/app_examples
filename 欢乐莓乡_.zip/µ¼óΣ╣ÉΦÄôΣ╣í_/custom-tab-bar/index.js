Component({
  data: {
    showBar: true,
    selected: 0,
    color: "rgb(51, 51, 51)",
    selectedColor: "rgb(249, 48, 43)",
    "list": [
      {
        "pagePath": "/pages/index/index",
        "text": "",
        "iconPath": "/tabbaricon/visit.png",
        "selectedIconPath": "/tabbaricon/visit_selected.png"
      },
      {
        "pagePath": "/pages/fruit/fruit",
        "text": "",
        "iconPath": "/tabbaricon/fruit.png",
        "selectedIconPath": "/tabbaricon/fruit_selected.png"
      },
      {
        "pagePath": "/pages/shopping_bag/shopping_bag",
        "text": "",
        "iconPath": "/tabbaricon/bag.png",
        "selectedIconPath": "/tabbaricon/bag_selected.png",
        bmClass: "bm"
      },
      {
        "pagePath": "/pages/shop/shop",
        "text": "",
        "iconPath": "/tabbaricon/alarm.png",
        "selectedIconPath": "/tabbaricon/alarm_selected.png"
      },
      {
        "pagePath": "/pages/user/user",
        "text": "",
        "iconPath": "/tabbaricon/user.png",
        "selectedIconPath": "/tabbaricon/user_selected.png"
      }
    ]
  },
  attached() {

  },
  methods: {
    toggleTabbar(e) {
      const data = e.currentTarget.dataset
      const url = data.path
      // console.log(data.path)
      wx.switchTab({url})
      this.setData({
        selected: data.index
      })
    }
  }
})