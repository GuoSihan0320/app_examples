module.exports = {
  accessKeyId: 'LTAI5tFcn9fqRU54dov6RFvp',
  accessKeySecret: '5fc9pBQAigwg49FhQ8BZ03gIWF8lcz'
}
