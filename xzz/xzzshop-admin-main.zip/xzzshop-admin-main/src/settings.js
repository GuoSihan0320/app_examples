module.exports = {
  title: '小猪猪后台管理',
  fixedHeader: true,
  sidebarLogo: true
}
